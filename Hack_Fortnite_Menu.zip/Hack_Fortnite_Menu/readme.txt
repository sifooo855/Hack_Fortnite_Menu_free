discord https://discord.gg/RZphdnYs7h
how setup download hack 
open Built
next open fortnite 
now you have hack menu